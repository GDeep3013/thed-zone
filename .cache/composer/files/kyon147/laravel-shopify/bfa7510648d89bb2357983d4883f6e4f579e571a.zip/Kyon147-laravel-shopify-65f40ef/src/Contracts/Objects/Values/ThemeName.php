<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Theme's name value object.
 */
interface ThemeName extends ValueObject
{
}
