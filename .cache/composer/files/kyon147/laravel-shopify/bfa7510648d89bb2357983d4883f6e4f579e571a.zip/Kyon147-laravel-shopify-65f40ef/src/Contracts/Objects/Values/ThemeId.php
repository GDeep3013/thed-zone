<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Theme's ID value object.
 */
interface ThemeId extends ValueObject
{
}
