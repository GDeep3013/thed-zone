<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Access token value object.
 */
interface ThemeSupportLevel extends ValueObject
{
}
