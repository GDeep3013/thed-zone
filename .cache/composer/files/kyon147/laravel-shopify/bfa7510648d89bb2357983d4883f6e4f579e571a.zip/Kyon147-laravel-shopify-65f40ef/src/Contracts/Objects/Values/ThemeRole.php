<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Theme's role value object.
 */
interface ThemeRole extends ValueObject
{
}
