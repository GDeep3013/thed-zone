<?php

namespace Osiset\ShopifyApp\Exceptions;

/**
 * Exception for when an API error occurs.
 */
class ApiException extends BaseException
{
}
