<?php

namespace Osiset\ShopifyApp\Exceptions;

/**
 * Exception for handling an invalid shop domain.
 */
class InvalidShopDomainException extends BaseException
{
}
