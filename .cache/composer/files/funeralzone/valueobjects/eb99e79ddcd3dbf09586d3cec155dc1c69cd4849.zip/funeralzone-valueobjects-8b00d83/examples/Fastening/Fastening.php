<?php

declare(strict_types=1);

namespace Funeralzone\ValueObjects\Examples\Fruit;

interface Fastening
{
}
