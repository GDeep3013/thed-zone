<?php

declare(strict_types=1);

namespace Funeralzone\ValueObjects\Sets;

use Exception;

final class SetsCanOnlyContainValueObjects extends Exception
{
}
