<?php

declare(strict_types=1);

namespace Funeralzone\ValueObjects\TestClasses;

final class NonValueObject
{
}
